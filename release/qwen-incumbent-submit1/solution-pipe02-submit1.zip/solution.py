import os
import sys
os.environ.setdefault('AUTOML_THREADS', '2')
from automl_runner import THREADS, llm_plan, main, run_worker
if __name__ == '__main__':
    if not any(arg == '--research-profile' or arg.startswith('--research-profile=') for arg in sys.argv[1:]):
        sys.argv.extend(['--research-profile', 'incumbent_mix'])
    main()
