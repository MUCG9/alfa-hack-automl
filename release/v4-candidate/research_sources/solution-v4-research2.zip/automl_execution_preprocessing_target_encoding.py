"""Smoothed categorical statistics with group-disjoint cross-fitting on fit rows."""
import numpy as np
import pandas as pd
from sklearn.model_selection import GroupKFold

def target_encode_frames(train_x, test_x, y, rows, hashes, classes=None, smoothing=20.0):
    rows = np.asarray(rows, dtype=int)
    categorical = [c for c in train_x if not pd.api.types.is_numeric_dtype(train_x[c])][:8]
    if not categorical:
        return (train_x, test_x)
    local_groups = np.asarray(hashes)[rows]
    folds = min(3, len(np.unique(local_groups)))
    if folds < 2:
        raise ValueError('Target encoding requires at least two independent feature groups')
    if classes is None:
        targets = np.asarray(y.iloc[rows], dtype=float).reshape(-1, 1)
    else:
        targets = (np.asarray(y.iloc[rows], dtype=str)[:, None] == np.asarray(classes, dtype=str)[None, :]).astype(float)
    splits = list(GroupKFold(folds).split(rows, groups=local_groups))
    train_x = train_x.copy()
    test_x = test_x.copy()
    for number, column in enumerate(categorical):
        train_key = train_x[column].fillna('__MISSING__').astype(str)
        test_key = test_x[column].fillna('__MISSING__').astype(str)
        keys = train_key.iloc[rows].reset_index(drop=True)

        def encode(indices, query, channel):
            values = targets[indices, channel]
            prior = float(values.mean())
            stats = pd.DataFrame({'key': keys.iloc[indices].to_numpy(), 'y': values}).groupby('key')['y'].agg(['sum', 'count'])
            mapping = (stats['sum'] + smoothing * prior) / (stats['count'] + smoothing)
            return query.map(mapping).fillna(prior).to_numpy(dtype='float32')
        for channel in range(targets.shape[1]):
            name = f'__te_{number}_{channel}'
            if name in train_x:
                raise ValueError('Target encoding feature collision')
            all_indices = np.arange(len(rows))
            encoded = encode(all_indices, train_key, channel)
            test_x[name] = encode(all_indices, test_key, channel)
            for fit, held in splits:
                encoded[rows[held]] = encode(fit, keys.iloc[held], channel)
            train_x[name] = encoded
    return (train_x, test_x)
