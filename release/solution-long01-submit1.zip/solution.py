import sys
from automl_runner import THREADS,llm_plan,main,run_worker
if __name__ == "__main__":
    sys.argv[1:1] = ["--offline", "--time-budget", "10800", "--search-until-deadline", "--finalization-reserve", "1200", "--max-extended-experiments", "1000"]
    main()
