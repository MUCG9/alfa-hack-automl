"""Only the coordinator's gateway receives credentials; domain code gets JSON."""
import json, os, time

def request_json(system_prompt, context, max_output=16384, timeout=300):
    if not all((os.environ.get(k) for k in ['OPENAI_API_KEY', 'OPENAI_BASE_URL'])):
        return (None, {'status': 'unconfigured'})
    from openai import OpenAI, BadRequestError, APIStatusError, APITimeoutError, APIConnectionError
    start = time.monotonic()
    usage = {}
    finish = None
    compatibility = False
    attempts = 0
    try:
        client = OpenAI(timeout=timeout, max_retries=0)
        request = {'model': os.environ.get('OPENAI_MODEL', 'qwen/qwen3.8-27b'), 'messages': [{'role': 'system', 'content': system_prompt}, {'role': 'user', 'content': json.dumps(context, ensure_ascii=False, default=str)}], 'temperature': 0.4, 'max_tokens': max_output, 'response_format': {'type': 'json_object'}}
        for retry in range(3):
            remaining = timeout - (time.monotonic() - start)
            if remaining < 5:
                raise TimeoutError('Gateway deadline')
            attempts += 1
            try:
                extra = {} if compatibility else {'extra_body': {'reasoning': {'enabled': False}}}
                response = client.with_options(timeout=remaining).chat.completions.create(**request, **extra)
                break
            except BadRequestError:
                if compatibility or retry == 2:
                    raise
                compatibility = True
            except (APIStatusError, APITimeoutError, APIConnectionError) as exc:
                status = getattr(exc, 'status_code', None)
                if status is not None and status != 429 and (status < 500):
                    raise
                if retry == 2:
                    raise
                pause = min(2 ** retry, max(0, timeout - (time.monotonic() - start) - 5))
                if pause:
                    time.sleep(pause)
        usage = response.usage.model_dump() if response.usage else {}
        finish = response.choices[0].finish_reason
        return (response.choices[0].message.content or '', {'status': 'ok', 'wall_seconds': round(time.monotonic() - start, 3), 'usage': usage, 'finish_reason': finish, 'compatibility_retry': compatibility, 'reasoning_requested': False, 'attempts': attempts, 'usage_complete': attempts == 1})
    except Exception as exc:
        message = str(exc).replace(os.environ.get('OPENAI_API_KEY', 'credential-unset'), '[REDACTED]')[:500]
        return (None, {'status': 'error', 'exception_type': type(exc).__name__, 'wall_seconds': round(time.monotonic() - start, 3), 'usage': usage, 'finish_reason': finish, 'compatibility_retry': compatibility, 'attempts': attempts, 'status_code': getattr(exc, 'status_code', None), 'error_message': message})
