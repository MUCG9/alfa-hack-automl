import sys
from automl_runner import THREADS,llm_plan,main,run_worker
if __name__ == "__main__":
    if not any(arg == "--time-budget" or arg.startswith("--time-budget=") for arg in sys.argv[1:]):
        sys.argv[1:1] = ["--offline", "--time-budget", "10800", "--search-until-deadline", "--finalization-reserve", "1200", "--max-extended-experiments", "1000"]
    main()
